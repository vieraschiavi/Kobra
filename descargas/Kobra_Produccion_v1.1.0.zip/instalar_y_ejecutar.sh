#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/kobra_software"
if command -v docker >/dev/null 2>&1; then
  echo '[Kobra] Docker detectado. Levantando servicios...'
  docker compose up --build -d
  echo '  Dashboard:  http://localhost:8501'
  echo '  Realtime :  http://localhost:8000'
else
  echo '[Kobra] Docker no encontrado. Instalación con Python local...'
  pip3 install -r requirements.txt
  python3 data/generate_dataset.py --n 12000 --seed 42
  python3 -m kobra.pipeline
  streamlit run app/app.py
fi

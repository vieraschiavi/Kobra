@echo off
title Kobra - Instalador
cd /d "%~dp0kobra_software"
where docker >nul 2>nul
if %errorlevel%==0 (
  echo [Kobra] Docker detectado. Levantando dashboard y servicio de audio...
  docker compose up --build -d
  echo.
  echo   Dashboard:  http://localhost:8501
  echo   Realtime :  http://localhost:8000
  start "" http://localhost:8501
  pause
  exit /b
)
where python >nul 2>nul
if %errorlevel%==0 (
  echo [Kobra] Docker no encontrado. Instalando con Python local...
  python -m pip install -r requirements.txt
  python data\generate_dataset.py --n 12000 --seed 42
  python -m kobra.pipeline
  start "" http://localhost:8501
  python -m streamlit run app\app.py
  exit /b
)
echo [Kobra] Instale Docker Desktop (recomendado) o Python 3.11+ y reintente.
pause
